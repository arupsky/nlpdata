import xml.etree.ElementTree as ElementTree
import json


class TrainingDataset:
	def __init__( self, _id, hyperpartsan, labeledBy, url, publishedAt, title, content):
		self._id = _id
		self.hyperpartsan = hyperpartsan
		self.labeledBy = labeledBy
		self.url = url
		self.publishedAt = publishedAt
		self.title = title
		self.content = content


# tds = TrainingDataset("_id", "hyperpartsan", "labeledBy", "url", "publishedAt", "title", "content")

# print (tds.content)

# jsonStr = json.dumps(tds.__dict__)

# print(jsonStr)

def element_to_string(element):
    s = element.text or ""
    for sub_element in element:
        s += ElementTree.tostring(sub_element, encoding='unicode')
    s += element.tail
    return s

file = '_articles-training-byarticle-20181122.xml'
tree = ElementTree.parse(file)
root = tree.getroot()
print(root)

articleID = ""

for article in root.iter('article'):
    if 'id' in article.attrib:
        articleID = article.attrib['id']
    else:
        articleID = ''
    if 'published-at' in article.attrib:
        pub = article.attrib['published-at']
    else:
        pub = ''
    if 'title' in article.attrib:
        articleTitle = article.attrib['title']
    else:
        articleTitle = ''

    contt = element_to_string(article)
    # print([articleID, pub, articleTitle, contt])

print([articleID, pub, articleTitle, contt])


# file2 = '_ground-truth-training-byarticle-20181122.xml'
# tree2 = ElementTree.parse(file2)
# root2 = tree2.getroot()

# for article in root2.iter('article'):
#     if 'hyperpartsan' in article.attrib:
#         hyperpartsan = article.attrib['hyperpartsan']
#     else:
#         hyperpartsan = ''
#     if 'labeled-by' in article.attrib:
#         labeledBy = article.attrib['labeled-by']
#     else:
#         labeledBy = ''
#     if 'url' in article.attrib:
#         url = article.attrib['url']
#     else:
#         url = ''

#     contt = element_to_string(article)
#     print([articleID, pub, articleTitle, contt])